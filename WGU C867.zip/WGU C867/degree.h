#pragma once
#include <string>
enum class DegreeProgram
{
    SECURITY,
    NETWORK,
    SOFTWARE
};
static const std::string degreeProgramStrings[] = {"SECURITY", "NETWORK", "SOFTWARE"};